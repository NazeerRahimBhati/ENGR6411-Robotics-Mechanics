clear
clc
%  (a) (i) problem inputs
disp('Please enter the Euler angles below:');
a = input('alfa in Degrees = ');
b = input('beta in Degrees= ');
g = input('gamma in Degrees= ');

ca = cosd(a);
cb = cosd(b);
cg = cosd(g);
sa = sind(a);
sb = sind(b);
sg = sind(g);

% To find Rotation Matrix from the Z-Y-X Euler angles  
% R = rotz * roty * rotx
a_rotm_b = [(ca*cb) ((ca*sb*sg)-(sa*cg)) ((ca*sb*cg)+(sa*sg)); (sa*cb) ((sa*sb*sg)+(ca*cg)) ((sa*sb*cg) - (ca*sg)); -sb (cb*sg) (cb*cg)] 

%  (b) (i) problem input from (a) (i)
rotm = a_rotm_b

beta =20
bp = [1;0;1]
% rotation beta about Y axis, standard rotation matrix is:
ry = [cosd(beta) 0 sind(beta); 0 1 0; -sind(beta) 0 cosd(beta)]
atb = [ry bp;0 0 0 1]
% we know that [ap; 1] = atb * [bp,1]
bp =[bp;1];
apm = atb * bp;
ap = [apm(1,1);apm(2,1); apm(3,1)]




%check using robotics tool box
euler_to_Trans = rpy2tr(g,b,a,'zyx')
trans_to_euler = rad2deg(tr2rpy(euler_to_Trans))

rotat_x = rotx(beta)
rotat_y = roty(beta)
rotat_z = rotz(beta)