clear
clc
beta =20
po = [0;0;0]
bp = [1;0;1]
% rotation beta about Y axis, standard rotation matrix is:
ry = [cosd(beta) 0 sind(beta); 0 1 0; -sind(beta) 0 cosd(beta)]
atb = [ry po;0 0 0 1]
% we know that [ap; 1] = atb * [bp,1]
bpp =[bp;1];
apm = atb * bpp;
ax =[-10 10 -10 10 -10 10];
ap = [apm(1,1);apm(2,1); apm(3,1)]
A= eye(3,3);
trplot(A,'frame','A','axis',ax)
hold on
trplot(atb,'frame','B')
plot_arrow([0,0,0],ap,'width', 0.1);

hold off

