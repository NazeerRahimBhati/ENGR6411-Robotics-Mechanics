clear
clc
%  (a) (i) problem inputs
disp('Please enter the Euler angles below:');
a = input('alfa in Degrees = ');
b = input('beta in Degrees= ');
g = input('gamma in Degrees= ');

ca = cosd(a);
cb = cosd(b);
cg = cosd(g);
sa = sind(a);
sb = sind(b);
sg = sind(g);

% To find Rotation Matrix from the Z-Y-X Euler angles  
% R = rotz * roty * rotx
a_rotm_b = [(ca*cb) ((ca*sb*sg)-(sa*cg)) ((ca*sb*cg)+(sa*sg)); (sa*cb) ((sa*sb*sg)+(ca*cg)) ((sa*sb*cg) - (ca*sg)); -sb (cb*sg) (cb*cg)] 

%  (b) (i) problem input from (a) (i)
rotm = a_rotm_b
% we know the relation below alfa beta gamma (Z-Y-X)euler angles and the roation matrix 
%  alfa, beta, gamma as a,b,g with cos fxn as c and sin fxn as s
% a_rotm_b = [(ca*cb) ((ca*sb*sg)-(sa*cg)) ((ca*sb*cg)+(sa*sg)); (sa*cb) ((sa*sb*sg)+(ca*cg)) ((sa*sb*cg) - (ca*sg)); -sb (cb*sg) (cb*cg)] 

beta = round(asind(-rotm(3,1)))

if(beta == 90)

   gamma = atan2d(rotm(1,2),rotm(2,2)) 
   
else
    gamma = round(acosd(rotm(3,3)/cosd(beta)))
    alfa = round(asind(rotm(2,1)/cosd(beta)))
end
clear

%  (a) (ii) problem inputs
disp('Please enter the Euler angles below:');
a = input('alfa in Degrees = ');
b = input('beta in Degrees= ');
g = input('gamma in Degrees= ');

ca = cosd(a);
cb = cosd(b);
cg = cosd(g);
sa = sind(a);
sb = sind(b);
sg = sind(g);

% To find Rotation Matrix from the Z-Y-X Euler angles  
% R = rotz * roty * rotx
a_rotm_b = [(ca*cb) ((ca*sb*sg)-(sa*cg)) ((ca*sb*cg)+(sa*sg)); (sa*cb) ((sa*sb*sg)+(ca*cg)) ((sa*sb*cg) - (ca*sg)); -sb (cb*sg) (cb*cg)] 

%  (b) (ii) problem input from (a) (ii)
rotm = a_rotm_b
% we know the relation below alfa beta gamma (Z-Y-X)euler angles and the roation matrix 
%  alfa, beta, gamma as a,b,g with cos fxn as c and sin fxn as s
% a_rotm_b = [(ca*cb) ((ca*sb*sg)-(sa*cg)) ((ca*sb*cg)+(sa*sg)); (sa*cb) ((sa*sb*sg)+(ca*cg)) ((sa*sb*cg) - (ca*sg)); -sb (cb*sg) (cb*cg)] 



beta = round(asind(-rotm(3,1)))

if(beta == 90)
   disp('Due to singularity infinite solutions so assume alfa = 0 degrees and find gamma');
    alfa = 0
   gamma = atan2d(rotm(1,2),rotm(2,2)) 
   
else
    gamma = round(acosd(rotm(3,3)/cosd(beta)))
    alfa = round(asind(rotm(2,1)/cosd(beta)))
end










