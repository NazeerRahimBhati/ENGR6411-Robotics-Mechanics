clear
clc
disp('Please enter the Euler angles below:');
a = input('alfa in Degrees = ');
b = input('beta in Degrees= ');
g = input('gamma in Degrees= ');

ca = cosd(a);
cb = cosd(b);
cg = cosd(g);
sa = sind(a);
sb = sind(b);
sg = sind(g);

% To find Rotation Matrix from the Z-Y-X Euler angles  
% R = rotz * roty * rotx
a_rotm_b = [(ca*cb) ((ca*sb*sg)-(sa*cg)) ((ca*sb*cg)+(sa*sg)); (sa*cb) ((sa*sb*sg)+(ca*cg)) ((sa*sb*cg) - (ca*sg)); -sb (cb*sg) (cb*cg)] 

% checking for the constraints
disp(' (i) Checking for the six constriants');
c_1 =  (a_rotm_b(1,1))^2 + (a_rotm_b(2,1))^2 + (a_rotm_b(3,1))^2
c_2 =  (a_rotm_b(1,2))^2 + (a_rotm_b(2,2))^2 + (a_rotm_b(3,2))^2
c_3 =  (a_rotm_b(1,3))^2 + (a_rotm_b(2,3))^2 + (a_rotm_b(3,3))^2

co4 =  [(a_rotm_b(1,1));(a_rotm_b(2,1));(a_rotm_b(3,1))];
co5 =  [(a_rotm_b(1,2));(a_rotm_b(2,2));(a_rotm_b(3,2))];
co6 =  [(a_rotm_b(1,3));(a_rotm_b(2,3));(a_rotm_b(3,3))];
c_4 = round(co4'*co5)
c_5 = round(co4'*co6)
c_6 = round(co5'*co6)
if (c_1==1 & c_2==1 & c_3==1 & c_4==0 & c_5==0 & c_6==0)
    disp('The Six conditions of Unitary orthonormal rotation matrix is satisfied');
end

b_rotm_a = round(inv(a_rotm_b),3)
trans_a_rotm_b = round(a_rotm_b',3)

if isequal(b_rotm_a,trans_a_rotm_b)
    disp(' The inverse of a rotation matrix is equal to its transpose');
end
disp('Please enter the Euler angles below:');
a = input('alfa in Degrees = ');
b = input('beta in Degrees= ');
g = input('gamma in Degrees= ');

ca = cosd(a);
cb = cosd(b);
cg = cosd(g);
sa = sind(a);
sb = sind(b);
sg = sind(g);

% To find Rotation Matrix from the Z-Y-X Euler angles  
% R = rotz * roty * rotx
a_rotm_b = [(ca*cb) ((ca*sb*sg)-(sa*cg)) ((ca*sb*cg)+(sa*sg)); (sa*cb) ((sa*sb*sg)+(ca*cg)) ((sa*sb*cg) - (ca*sg)); -sb (cb*sg) (cb*cg)] 


